<!DOCTYPE html>
<html>
<body>

<h2>Delete Employee</h2>

<form action="employee" method="post">
    <input type="hidden" name="action" value="delete">

    Enter Employee ID:
    <input type="text" name="id"><br><br>

    <input type="submit" value="Delete Employee">
</form>

<br>
<a href="index.jsp">Back to Home</a>

</body>
</html>
