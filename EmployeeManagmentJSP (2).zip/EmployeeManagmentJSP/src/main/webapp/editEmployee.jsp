<%@ page import="com.test.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Employee</title>
</head>
<body>

<h2>Edit Employee</h2>

<%
    Employee emp = null;
    String idParam = request.getParameter("id");

    if (idParam != null && !idParam.isEmpty()) {
        int id = Integer.parseInt(idParam);
        EmployeeDao dao = new EmployeeDaoImpl();

        for (Employee e : dao.getAllEmployee()) {
            if (e.getId() == id) {
                emp = e;
                break;
            }
        }

        if (emp == null) {
%>
            <p style="color:red;">Employee not found!</p>
<%
        }
    }
%>

<form method="get" action="editEmployee.jsp">
    Enter Employee ID:
    <input type="text" name="id" required>
    <input type="submit" value="Search">
</form>

<br>

<% if (emp != null) { %>

<form action="employee" method="post">
    <input type="hidden" name="action" value="update">

    ID:
    <input type="text" name="id" value="<%= emp.getId() %>" readonly><br><br>

    Name:
    <input type="text" name="name" value="<%= emp.getName() %>" required><br><br>

    Salary:
    <input type="text" name="salary" value="<%= emp.getSalary() %>" required><br><br>

    Department:
    <input type="text" name="department" value="<%= emp.getDepartment() %>" required><br><br>

    <input type="submit" value="Update Employee">
</form>

<% } %>

<br>
<a href="index.jsp">Back to Home</a>

</body>
</html>
