<!DOCTYPE html>
<html>
<body>

<h2>Add Employee</h2>

<form action="employee" method="post">
    <input type="hidden" name="action" value="add">

    Employee ID: <input type="text" name="id"><br><br>
    Name: <input type="text" name="name"><br><br>
    Salary: <input type="text" name="salary"><br><br>
    Department: <input type="text" name="department"><br><br>

    <input type="submit" value="Add Employee">
</form>

<br>
<a href="index.jsp">Back to Home</a>

</body>
</html>
