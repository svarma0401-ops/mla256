<%@ page import="java.util.*, com.test.*" %>
<!DOCTYPE html>
<html>
<body>

<h2>Employee List</h2>

<table border="1">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Salary</th>
    <th>Department</th>
</tr>

<%
    EmployeeDao dao = new EmployeeDaoImpl();
    for(Employee e : dao.getAllEmployee()) {
%>
<tr>
    <td><%= e.getId() %></td>
    <td><%= e.getName() %></td>
    <td><%= e.getSalary() %></td>
    <td><%= e.getDepartment() %></td>
</tr>
<% } %>

</table>

<br>
<a href="index.jsp">Back to Home</a>

</body>
</html>
